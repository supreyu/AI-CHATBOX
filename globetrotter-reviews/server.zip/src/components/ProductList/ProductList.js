import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './ProductList.css';

const ProductList = () => {
  const [products, setProductList] = useState([]);

  useEffect(() => {
    fetch('/api/ProductList')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        setProductList(data);
      })
      .catch((error) => {
        console.error('Fetch error:', error);
      });
  }, []);

  const addToCart = (productId) => {
    // TODO: Implement the logic to add the product to the cart
    console.log('Add to cart:', productId);
  };

  return (
    <div className="product-list-container">
      <h1>Product List</h1>
      <div className="products">
        {products.map((product) => (
          <div key={product.id} className="product">
            <Link to={`/products/${
              product.id}`}>
              <img src={product.cover_image} alt={product.title} />
              <h3>{product.title}</h3>
              </Link>
              <p className="product-price">¥{product.price}</p>
              <button className="add-to-cart-btn" onClick={() => addToCart(product.id)}>
              add cart
              </button>
              </div>
            ))}
        </div>
      </div>
);
};

export default ProductList;