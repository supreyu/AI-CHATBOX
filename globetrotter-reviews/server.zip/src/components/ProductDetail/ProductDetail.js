
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './ProductDetail.css';

const ProductDetail = () => {
  const [product, setProduct] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
      })
      .then(data => setProduct(data))
      .catch(error => console.error('Error fetching product details:', error));
  }, [id]);

  const addToCart = () => {
    console.log('Add to cart:', product.id);
    // 这里将调用添加到购物车的API
  };

  const buyNow = () => {
    console.log('Buy now:', product.id);
    // 这里将调用立即购买的API
  };

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div className="product-detail-container">
      <div className="product-cover-and-info">
        <img src={product.cover_image} alt={product.title} className="product-cover" />
        <div className="product-info">
          <h2>{product.title}</h2>
          <p><strong>Price:</strong> {product.price}</p>
          <p><strong>Description:</strong> {product.description}</p>
          <p><strong>Type:</strong> {product.type}</p>
          <p><strong>Stock:</strong> {product.stock || 'In stock'}</p>
          <div className="product-actions">
            <button className="button" onClick={addToCart}>addToCart</button>
            <button className="button" onClick={buyNow}>Buy Now</button>
          </div>
        </div>
    </div>
  </div>
);
};

export default ProductDetail;