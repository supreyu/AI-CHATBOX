// NavBar.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import './NavBar.css';

const NavBar = () => {
  const [cartVisible, setCartVisible] = useState(false);
  const [cartItems, setCartItems] = useState([]);

  // useEffect(() => {
  //   // Function to fetch cart items from the database
  //   const fetchCartItems = async () => {
  //     try {
  //       const response = await apiService.get('/cart');
  //       setCartItems(response.data); // Assuming the response has a data property with the items
  //     } catch (error) {
  //       console.error("Error fetching cart items", error);
  //     }
  //   };
    
  //   fetchCartItems();
  // }, []);






  // 鼠标移入事件处理函数
  const handleMouseEnter = () => {
    setCartVisible(true);
  };

  // 鼠标移出事件处理函数
  const handleMouseLeave = () => {
    setCartVisible(false);
  };
  
  return (
    <nav className="navbar">
      <ul>
        <li><Link to="/" className="nav-btn">Home</Link></li>
        <li><Link to="/ProductList" className="nav-btn">Products</Link></li>
        {/* 添加其他导航项 */}
      </ul>

      <div className="nav-right">
        <div className="shopping-cart-icon"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave} 
        >
          {/* 购物车 */}
          <FontAwesomeIcon icon={faShoppingCart} />
          {/* 下拉框 */}
          {cartVisible && (
            <div className="shopping-cart-dropdown">
              {cartItems.length > 0 ? (
                <ul className="cart-items">
                  {cartItems.map(item => (
                    <li key={item.id} className="cart-item">
                      <img src={item.cover_image} alt={item.title} className="cart-item-image" />
                      <div className="cart-item-description">{item.title}</div>
                      <div className="cart-item-price">£{item.price.toFixed(2)}</div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="empty-cart">Your cart is empty</div>
              )}
            </div>
          )}
        </div>
        <div className="search-bar">
          <input type="text" placeholder="Search for products" />
          <button type="button" className="search-btn">Search</button>
        </div>
        <div className="login">
          <Link to="/login" className="login-btn">Login</Link>
          <Link to="/register" className="register-btn">Register</Link>
          <Link to="/AddProduct" className="login-btn">AddProduct</Link>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;


