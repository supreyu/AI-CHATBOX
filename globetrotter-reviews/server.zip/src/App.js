// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/Home/Home';
import ProductList from './components/ProductList/ProductList';
import AuthorList from './components/AuthorList/AuthorList';
import UserProfile from './components/UserProfile/UserProfile';
import NavBar from './components/NavBar/NavBar';
import Login from './components/Login/Login';
import Register from './components/Register/Register';
import ProductDetail from './components/ProductDetail/ProductDetail'; // 同样，路径可能需要调整
import AddProduct from './components/AddProduct/AddProduct';
import ChatInterface from './components/ChatInterface/ChatInterface';


function App() {
  return (
    <Router>
      <div>
        <NavBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ProductList" element={<ProductList />} />
          <Route path="/authors" element={<AuthorList />} />
          <Route path="/products/:id" element={<ProductDetail />} />
          <Route path="/user/:id" element={<UserProfile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/AddProduct" element={<AddProduct />} /> 
          <Route path="/chat" element={<ChatInterface />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

